package com.DeptManage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.DeptManage.entity.Dept;
import com.DeptManage.service.DeptService;


@Controller
public class DeptController {

	@Autowired
	private DeptService deptService;
	
	//跳转到list页面，展示所有数据
	@RequestMapping(value = "/list")
	public String list(Model model) {
		System.out.println("查询所有信息！");
		List<Dept> depts=deptService.findAll();
		//model是作为前后台的一个交互作用的,往前台传数据，可以传对象，可以传List，通过el表达式 ${}可以获取到，类似于request.setAttribute("sts",sts)效果一样
        model.addAttribute("depts", depts);
        return "list";
	}
	
	//跳转到edit页面，并将根据id查找到部门数据传入edit
	@RequestMapping("/toEdit")
	 public String toEdit(Model model,Long id) {
        Dept dept = deptService.findById(id);
        model.addAttribute("dept", dept);
        return "edit";
    }

	//编辑部门信息，更新之后再转到list页面
	@RequestMapping("/edit")
    public String edit(Dept dept) {
        deptService.update(dept);
        return "redirect:/list";
    }
	
	//删除部门信息
	@RequestMapping("/toDelete")
    public String delete(Long id) {
        deptService.delete(id);
        System.out.println("删除成功！");
        return "redirect:/list";
    }
	
	//跳转到add页面
	@RequestMapping("/toAdd")
    public String toAdd() {
        return "add";
    }
	
	//添加部门信息，添加完成之后转到list页面
	@RequestMapping("/add")
    public String add(Dept dept) {
        deptService.add(dept);
        System.out.println("添加成功！");
        return "redirect:/list";
    }
}
